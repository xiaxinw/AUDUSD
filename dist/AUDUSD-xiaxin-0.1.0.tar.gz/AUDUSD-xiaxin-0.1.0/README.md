function for AUD and USD from Max's code
